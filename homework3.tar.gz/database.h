/*****************************************************************
//
//  NAME:        Jonathan Ma
//
//  HOMEWORK:    3
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        September 29, 2020
//
//  FILE:        database.h
//
//  DESCRIPTION:
//   Contains all the function declarations for the database access.
//
****************************************************************/
#ifndef database_h
#define database_h
#include "record.h"

int addRecord (struct record **start, int, char[], char[]);
void printAllRecords ( struct record *start);
int findRecord (struct record *start, int);
int deleteRecord ( struct record **start, int);

#endif
