/*****************************************************************
//
//  NAME:        Jonathan Ma
//
//  HOMEWORK:    3
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        October 2, 2020
//
//  FILE:        database.c
//
//  DESCRIPTION:
//   Contains all the functions for the database.
//
****************************************************************/
#include <stdio.h>
#include "record.h"
#include "database.h"
extern int debugMode;
/*****************************************************************
//
//  Function name: addRecord
//
//  DESCRIPTION:   This function gets the users
//                 name and account number
//                 
//
//  Parameters:    bar (int) : The account number
//                 bar (char[]): The users name
//                 bar (char[]); The users mailing address
//
//  Return values:  0 : The users name, account number, and mailing address are 
//                      registered successfully.
//                 
//                 de
//                 
****************************************************************/

int addRecord (struct record **start, int accountnum, char name[],char address[])
{
    if(debugMode == 1 )
{
    printf("\nFunction addRecord called, paramters passed are account number, name, and  mailing address.\n");
    
}
return 0;
}
/******************************************************************
//
//
//  Function name: printALLRecords
//
//  Description:   This function will print the records of all the 
//                 the clients information.
//
//  
//
//  Parameters:    bar (struct record): Contains the datatypes of 
//                                      name, accoount number, and 
//                                      mailing address.
//
//
//  
//  return values:   none
// 
//
//
//
*******************************************************************/
void printAllRecords(struct record *start)
{
    if(debugMode == 1)
{
    printf("\nFunction printALLRecords called.\n");
}
}
/*******************************************************************
//  Function name: findRecord
//
//  parameters:    bar (struct record): Contains the datatypes of 
//                                      client name, account number
//                                      and mailing address
//                 
//                 bar (int): The account number
//
//
//
//  return values:  0: The record of the account associated with the 
//                     account number is returned 
//                
//
//
*********************************************************************/
int findRecord(struct record *start, int accountnum)
{
    if(debugMode == 1)
{
    printf("\nFunction findRecord called, account number is passed.\n");
}
return 0;
}
/********************************************************************
//  Function name: deleteRecord
//
//  parameters:    bar (struct record): Contains the datatypes for 
//                                      client name, account, and account 
//                                      number
//                 bar (int): The account number
//
//  return values: 0: successful deletion of an account
//
********************************************************************/
int deleteRecord(struct record **start, int accountnum)
{
    if(debugMode == 1)
{
    printf("\nFunction deleteRecord called, account number is passed.\n");
}
return 0;
}

