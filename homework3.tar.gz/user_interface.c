/*****************************************************************
//  NAME:        Jonathan Ma
//  //
//  //  HOMEWORK:    3
//  //
//  //  CLASS:       ICS 212
//  //
//  //  INSTRUCTOR:  Ravi Narayan
//  //
//  //  DATE:        October 4, 2020
//  //
//  //  FILE:        user_interface.c
//  //
//  //  DESCRIPTION:
//  //   Contains the program of the user interface to database
//  //
//  ****************************************************************/
#include <stdio.h>
#include <string.h>
#include "record.h"
#include "database.h"

int debugMode;
void getaddress(char[], int);
void getname(char []);

int main(int argc, char *argv[])
{

char userInput[7];
char* p;

struct record * start = NULL;

if(argc == 1)
{
    debugMode = 0;
}

if(argc == 2)
{
    if(strcmp(argv[1], "debug") == 0)
    {
        debugMode = 1;
    }
    else
    {
        printf("To enter debug mode type 'debug'.");
    }

}

if(argc > 2)
{
    printf("To enter debug mode type 'debug'.");
}


  
printf("|-------------------------------------------------------------------------------------------------------------------|\n");
printf("|This program allows you to add, delete, print all client info, or find a specific account using the account number.|\n");
printf("|-------------------------------------------------------------------------------------------------------------------|\n\n");
printf("Please type an option below of your choice.\n\n");
printf("<ADD>\n");
printf("<PRINTALL>\n");
printf("<FIND>\n");
printf("<DELETE>\n");
printf("<QUIT>\n\n");
 
do
{
    
    
    printf("\nEnter your choice=====>");
   
    fgets(userInput, 7, stdin);
 
    if(memcmp(userInput, "a", 1) == 0)
    {
        char name[25];
        char addr[80];
	int accnum = 0; 
        
        getname(name);
        printf("Please enter a POSITIVE account number===>");
        scanf("%d", &accnum);
        getchar();
        getaddress(addr, 80);      
        addRecord(&start, accnum, name, addr);
        printf("\nThank you %syour account number is: %d\nyour address is:\n%s\n", name, accnum, addr);
    }
 
    else if(memcmp(userInput, "p", 1) == 0)
    {
        int accnum = 0;
        printf("Please enter a POSITIVE account number===>");
        scanf("%d", &accnum);
        getchar();
        printAllRecords(start);
    }
 
    else if(memcmp(userInput, "q", 1) == 0)
    {
        p = userInput;
        printf("Thanks for using.\n");
    }
 
    else if(memcmp(userInput, "f", 1)  == 0)
    {
        int accnum = 0;
        printf("Please enter a POSITIVE account number to look for===>");
        scanf("%d", &accnum);
        getchar();
        findRecord (start, accnum);
    }

    else if(memcmp(userInput, "d", 1) == 0)
    {
        int accnum = 0;
        printf("Please enter a POSITIVE account number to delete===>");
        scanf("%d", &accnum);
        getchar();
        deleteRecord(&start, accnum);
    }
      
    else
    {
        printf("Please enter a correct option.\n");
    }
}while(p != userInput);

return 0;
}

/*****************************************************************
 *//
//  Function name: getaddress
//  //
//  //  DESCRIPTION:   The function that gets the address from user.
//  //                 
//  //
//  //  Parameters:    max (int) : The maximum size for the address array.
//  //                             
//  //                 address (char[]) : The address array in whic the address is stored.
//  //
//  ****************************************************************/

void getaddress(char address[], int max)
{
    int i;
    printf("Please type your address, it must be no more than 80 characters long, double enter to stop====>");
    for ( i = 0; i < max; i++)
    {
        address[i] = fgetc(stdin);
        if ( address[i] == '\n' && address[i - 1] == '\n')
        {
            address[i++] = '\0';
            break;
        }
        if ( i >= max)
        {
            break;
        }
    }
}

/*****************************************************************
 *//
//  Function name: getname
//  //
//  //  DESCRIPTION:   Gets the name of the user
//  //                 
//  //
//  //  Parameters:    name (char[]) : The array where the name is stored.
//  //
//  //
//  ****************************************************************/

void getname(char name[])
{
    
    int i = 0;
    while( i == 0)
    {
        printf("Please type your name, press enter to continue===>");

        fgets(name, 25, stdin);
        if(strchr(name, '\t'))
        {
            printf("No tabs allowed in between name.\n");
        } 
        else
        {
            i  = 1;
        }
    }
}
