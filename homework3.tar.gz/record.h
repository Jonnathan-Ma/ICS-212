/*****************************************************************
//
//  NAME:        Jonathan Ma
//
//  HOMEWORK:    3
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        September 29, 2020
//
//  FILE:        record.h
//
//  DESCRIPTION:
//   Data structure of the record.
//
****************************************************************/
#ifndef record_h
#define record_h
struct record
{
    int                 accountnum;
    char                name[25];
    char                address[80];
    struct record*      next;
};

#endif
